package comedorescolar;

public class SistemaDeAlmuerzo {

    public void gestionarRetiroAlmuerzo(Estudiante estudiante, Almuerzo almuerzo) {
        // gestionar el retiro de un almuerzo por parte de un estudiante
        // verificar disponibilidad del almuerzo y llamar al método retirar() del almuerzo
    }

}
