package comedorescolar;

public class Factura {

}
