package comedorescolar;

import java.time.LocalDate;
import java.util.List;

public class SistemaDeAsistencia {

    private List<Estudiante> estudiantes;

    public boolean registrarAsistencia(Estudiante estudiante, LocalDate fecha) {
        return true;
    }
}
